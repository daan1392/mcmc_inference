import os,sys, glob
import pandas as pd
import matplotlib.pyplot as plt 

def mv_file(name, newname, job_name):
        if os.path.isfile(name):
           dst = job_name + "." + newname
           dst=os.path.join("results", dst)
           os.replace(name,dst)

def remove_sammy_files():
    inp='input'
    if os.path.isfile(inp):os.remove(inp)
    out='output'
    if os.path.isfile(out):os.remove(out)
    files = glob.glob("SAM*")
    for  f in files : os.remove(f)

def get_program_name(name):
    sammy_inst= os.environ.get('SAMMY_INST')
    program=os.path.join(sammy_inst,name)
    os.makedirs('results', exist_ok=True)
    return program

def move_standard_files(job_name):
    mv_file('SAMMY.IO','io',job_name)
    mv_file('SAMMY.LST','lst',job_name)
    mv_file('SAMMYX.LST','xlst',job_name)
    mv_file('SAMMY.PAR','par',job_name)
    mv_file('SAMMY.COV','cov',job_name)
    mv_file('SAMNDF.PAR','par',job_name)
    mv_file('SAMNDF.INP','inp',job_name)
    mv_file('SAMNDF.NDF','endf',job_name)
    mv_file('SAMNDF.NDX','endx',job_name)    
        
    
