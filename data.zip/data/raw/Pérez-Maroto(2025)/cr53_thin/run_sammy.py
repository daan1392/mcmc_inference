import os,sys, glob
import pandas as pd
import matplotlib.pyplot as plt

current_script_path = os.path.abspath(__file__)
parent_dir_script = os.path.dirname(current_script_path)
parent_dir_script = os.path.dirname(parent_dir_script)
sys.path.append(parent_dir_script)
from functions import *

    
def run_sammy_explicit_filenames(inp_file, par_file, dat_file, cov_file, job_name, emin, emax):
        sammy =  get_program_name('sammy')

        # driver input/output files to run SAMMY optionally defined
        inp='input'
        out='output'
        remove_sammy_files()

        with open(inp,'w+') as f:
                f.write(f'{inp_file}\n')
                f.write(f'{par_file}\n')
                f.write(f'{dat_file} {emin},{emax}\n')
                if os.path.isfile(f'{cov_file}'):
                        f.write(f'{cov_file}\n')

        os.system(f'{sammy}<{inp}>{out}')

        move_standard_files(job_name)
        #remove_sammy_files()

run_sammy = run_sammy_explicit_filenames


run_sammy('cr53_thin.inp', 'cr53_thin.par' ,'cr53thin_preyield_fixL_18394_17ns_250bpd.dat', '', 'cr53_thin', '1000.0', '10000.0') #
name='cr53_thin' # root name (no extension) for output renaming and plotting

data = pd.read_csv(f'results/{name}.lst', sep='\s+', header=None)
df = pd.DataFrame(data)
num_cols_len = len(df.columns)

if num_cols_len == 4: data.columns = ['e', 'x', 'dx', 'prior_th']
if num_cols_len == 5: data.columns = ['e', 'x', 'dx', 'prior_th', 'post_th']

fig, ax = plt.subplots(figsize=(10, 6))

ax.errorbar(data['e'], data['x'], yerr=data['dx'], 
             label='Measured data', fmt='o', capsize=5, elinewidth=2, color='black',zorder=0)
ax.plot(data['e'], data['prior_th'], label='Theoretical (no Bayes)', marker='', color='red',linewidth=2)
if num_cols_len == 5: ax.plot(data['e'], data['post_th'], label='Theoretical (Bayes)', marker='', color='orange',linewidth=2)

ax.set(
    title=f'Test case {name}',
    xlabel='Incident neutron energy (eV)',
    ylabel='Capture yield',
#     xscale='log',
    # yscale='log'
)
ax.legend()
ax.grid()
# Save the figure
fig.savefig(f'results/{name}.pdf')

sys.exit()
